
/* =========================================================
   PRELOADER GFF
   Tela inicial de carregamento com duração de 2,5 segundos.
   ========================================================= */

(function initPreloader() {
    const preloader = document.getElementById("sitePreloader");
    const progressBar = document.getElementById("preloaderProgress");
    const progressText = document.getElementById("preloaderPercent");

    if (!preloader) {
        return;
    }

    document.body.classList.add("is-loading");

    const startTime = performance.now();
    const duration = 2500;
    let finished = false;

    const updateProgress = (value) => {
        const progress = Math.min(100, Math.max(0, value));

        if (progressBar) {
            progressBar.style.width = `${progress}%`;
        }

        if (progressText) {
            progressText.textContent = `${Math.round(progress)}%`;
        }
    };

    const animateProgress = () => {
        if (finished) {
            return;
        }

        const elapsed = performance.now() - startTime;
        const progress = Math.min(94, (elapsed / duration) * 94);

        updateProgress(progress);
        window.requestAnimationFrame(animateProgress);
    };

    window.requestAnimationFrame(animateProgress);

    const finish = () => {
        if (finished) {
            return;
        }

        const elapsed = performance.now() - startTime;
        const remaining = Math.max(0, duration - elapsed);

        window.setTimeout(() => {
            if (finished) {
                return;
            }

            finished = true;
            updateProgress(100);

            /*
             * A tela permanece em primeiro plano por 2,5s.
             * Depois, desaparece suavemente para revelar o site.
             */
            preloader.classList.add("is-hidden");
            document.body.classList.remove("is-loading");

            window.setTimeout(() => {
                preloader.remove();
            }, 500);
        }, remaining);
    };

    if (document.readyState === "complete") {
        finish();
    } else {
        window.addEventListener("load", finish, { once: true });
    }

    /* Segurança para conexões muito lentas. */
    window.setTimeout(finish, 12000);
})();




const posts = [
  {
    id: 1,
    source: 'STF',
    date: '28 AGO 2026',
    title: 'STF analisa temas de relevância para a sociedade brasileira',
    summary: 'Acompanhe os principais julgamentos e decisões recentes do Supremo Tribunal Federal.',
    cat: 'Jurisprudência',
    body: 'Conteúdo demonstrativo. Esta publicação deverá ser substituída pela integração com a fonte oficial do STF. A página foi estruturada para apresentar resumo, contexto e link para a publicação original.'
  },
  {
    id: 2,
    source: 'STJ',
    date: '27 AGO 2026',
    title: 'STJ atualiza entendimento em matéria de direito privado',
    summary: 'Síntese informativa sobre decisão recente e seus principais fundamentos.',
    cat: 'Jurisprudência',
    body: 'Conteúdo demonstrativo. Na versão de produção, o sistema poderá importar dados permitidos por API, RSS ou outro mecanismo oficial.'
  },
  {
    id: 3,
    source: 'STF',
    date: '26 AGO 2026',
    title: 'Supremo publica novas informações sobre sua jurisprudência',
    summary: 'Confira a atualização e consulte a publicação oficial do Tribunal.',
    cat: 'STF',
    body: 'Conteúdo demonstrativo para desenvolvimento do layout.'
  },
  {
    id: 4,
    source: 'STJ',
    date: '25 AGO 2026',
    title: 'Decisão do STJ reforça a importância da análise contratual',
    summary: 'Uma visão geral de atualização jurisprudencial para acompanhamento profissional.',
    cat: 'STJ',
    body: 'Conteúdo demonstrativo para desenvolvimento do layout.'
  }
];

function render() {
  const element = document.querySelector('#posts');

  if (!element) return;

  const query = (document.querySelector('#search')?.value || '').toLowerCase();
  const filter = document.querySelector('.filter.active')?.dataset.filter || 'Todos';

  const filteredPosts = posts.filter((post) => {
    const matchesFilter = filter === 'Todos' || post.source === filter || post.cat === filter;
    const matchesSearch = `${post.title} ${post.summary}`.toLowerCase().includes(query);
    return matchesFilter && matchesSearch;
  });

  element.innerHTML =
    filteredPosts
      .map(
        (post) => `
          <a class="blog-card reveal visible" href="noticia.html?id=${post.id}">
            <div class="blog-card-top">
              <span>${post.source}</span>
              <time>${post.date}</time>
            </div>
            <div class="blog-card-body">
              <small>${post.cat}</small>
              <h3>${post.title}</h3>
              <p>${post.summary}</p>
            </div>
            <b>Continuar leitura <span>↗</span></b>
          </a>`
      )
      .join('') || '<p class="empty">Nenhuma publicação encontrada.</p>';
}

document.querySelectorAll('.filter').forEach((button) =>
  button.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach((item) => item.classList.remove('active'));
    button.classList.add('active');
    render();
  })
);

document.querySelector('#search')?.addEventListener('input', render);
render();

const article = document.querySelector('#article');

if (article) {
  const id = new URLSearchParams(location.search).get('id');
  const post = posts.find((item) => String(item.id) === id) || posts[0];

  article.innerHTML = `
    <div class="article-top">
      <a href="blog.html">← Voltar ao blog</a>
      <span>${post.source} · ${post.date}</span>
    </div>
    <div class="article-grid">
      <div>
        <small>${post.cat}</small>
        <h1>${post.title}</h1>
        <p class="article-summary">${post.summary}</p>
      </div>
      <div class="article-side">
        <span>GFF</span>
        <small>ATUALIZAÇÃO<br>JURÍDICA</small>
      </div>
    </div>
    <div class="article-body">
      <p>${post.body}</p>
      <p>Na publicação definitiva, o conteúdo deverá apresentar a fonte oficial e o respectivo link para consulta no portal do tribunal.</p>
      <div class="source-box">
        <span>FONTE OFICIAL</span>
        <strong>Portal do ${post.source}</strong>
        <a href="#" onclick="return false">Consultar publicação original ↗</a>
      </div>
    </div>`;

  document.title = `${post.title} | GFF`;
}


document.addEventListener("click", (event) => {
    if (
        lawyerMenu &&
        !lawyerMenu.contains(event.target)
    ) {
        lawyerMenu.classList.remove("is-open");
        lawyerTrigger?.setAttribute(
            "aria-expanded",
            "false"
        );
    }
});
