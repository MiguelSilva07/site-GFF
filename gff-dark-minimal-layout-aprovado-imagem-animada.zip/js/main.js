
/* =========================================================
   PRELOADER GFF
   Tela inicial de carregamento com duração de 2,5 segundos.
   ========================================================= */

(function initPreloader() {
    const preloader = document.getElementById("sitePreloader");
    const stage = preloader?.querySelector(".preloader-stage");
    const progressBar = document.getElementById("preloaderProgress");
    const progressText = document.getElementById("preloaderPercent");

    if (!preloader) {
        return;
    }

    document.body.classList.add("is-loading");

    const duration = 2500;
    const start = performance.now();

    function update(timestamp) {
        const elapsed = timestamp - start;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 2);

        stage?.style.setProperty("--progress", eased);

        if (progressBar) {
            progressBar.style.width = `${eased * 100}%`;
        }

        if (progressText) {
            progressText.textContent = `${Math.round(eased * 100)}%`;
        }

        if (progress < 1) {
            requestAnimationFrame(update);
            return;
        }

        window.setTimeout(() => {
            preloader.classList.add("is-hidden");
            document.body.classList.remove("is-loading");

            window.setTimeout(() => {
                preloader.remove();
            }, 700);
        }, 100);
    }

    requestAnimationFrame(update);
})();




const progress = document.querySelector('.progress');

const observer = new IntersectionObserver(
  (entries) =>
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    }),
  { threshold: 0.12 }
);

document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));

const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');

menu?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menu.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.main-nav a').forEach((link) =>
  link.addEventListener('click', () => nav?.classList.remove('open'))
);

window.addEventListener(
  'scroll',
  () => {
    const height = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.width = `${height > 0 ? (window.scrollY / height) * 100 : 0}%`;
    document.querySelector('.site-header')?.classList.toggle('scrolled', window.scrollY > 30);
  },
  { passive: true }
);

const posts = [
  {
    id: 1,
    source: 'STF',
    date: '28 AGO 2026',
    title: 'STF analisa temas de relevância para a sociedade brasileira',
    summary: 'Acompanhe os principais julgamentos e decisões recentes do Supremo Tribunal Federal.',
    cat: 'Jurisprudência'
  },
  {
    id: 2,
    source: 'STJ',
    date: '27 AGO 2026',
    title: 'STJ atualiza entendimento em matéria de direito privado',
    summary: 'Síntese informativa sobre decisão recente e seus principais fundamentos.',
    cat: 'Jurisprudência'
  },
  {
    id: 3,
    source: 'STF',
    date: '26 AGO 2026',
    title: 'Supremo publica novas informações sobre sua jurisprudência',
    summary: 'Confira a atualização e consulte a publicação oficial do Tribunal.',
    cat: 'STF'
  }
];

const home = document.querySelector('#homePosts');

if (home) {
  home.innerHTML = posts
    .map(
      (post, index) => `
        <a class="blog-card ${index === 0 ? 'featured' : ''} reveal visible" href="noticia.html?id=${post.id}">
          <div class="blog-card-top">
            <span>${post.source}</span>
            <time>${post.date}</time>
          </div>
          <div class="blog-card-body">
            <small>${post.cat}</small>
            <h3>${post.title}</h3>
            <p>${post.summary}</p>
          </div>
          <b>Continuar leitura <span>↗</span></b>
        </a>`
    )
    .join('');
}


document.addEventListener("click", (event) => {
    if (
        lawyerMenu &&
        !lawyerMenu.contains(event.target)
    ) {
        lawyerMenu.classList.remove("is-open");
        lawyerTrigger?.setAttribute(
            "aria-expanded",
            "false"
        );
    }
});


/* =========================================================
   FORMULÁRIO DO CLIENTE
   ========================================================= */

(function initClientContactForm() {
    const form = document.getElementById("clientContactForm");

    if (!form) {
        return;
    }

    const status = document.getElementById("clientContactStatus");
    const phone = form.querySelector('[name="telefone"]');

    function error(field, message) {
        field.setAttribute("aria-invalid", "true");

        const output =
            field.parentElement.querySelector(".gff-form-error");

        if (output) {
            output.textContent = message;
        }
    }

    function clear(field) {
        field.removeAttribute("aria-invalid");

        const output =
            field.parentElement.querySelector(".gff-form-error");

        if (output) {
            output.textContent = "";
        }
    }

    function validate() {
        let valid = true;

        form.querySelectorAll("[required]").forEach((field) => {
            clear(field);

            if (
                field.type === "checkbox" &&
                !field.checked
            ) {
                error(
                    field,
                    "É necessário autorizar o contato."
                );
                valid = false;
                return;
            }

            if (
                field.type !== "checkbox" &&
                !field.value.trim()
            ) {
                error(field, "Este campo é obrigatório.");
                valid = false;
            }
        });

        const email = form.querySelector('[name="email"]');

        if (email.value.trim()) {
            const validEmail =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                    email.value.trim()
                );

            if (!validEmail) {
                error(email, "Informe um e-mail válido.");
                valid = false;
            }
        }

        const digits = phone.value.replace(/\D/g, "");

        if (digits.length < 10) {
            error(phone, "Informe um WhatsApp válido.");
            valid = false;
        }

        return valid;
    }

    phone?.addEventListener("input", (event) => {
        let value = event.target.value.replace(/\D/g, "");

        if (value.length > 11) {
            value = value.slice(0, 11);
        }

        if (value.length <= 10) {
            value = value.replace(
                /^(\d{2})(\d{0,4})(\d{0,4}).*/,
                (_, ddd, first, second) =>
                    `(${ddd}) ${first}${second ? `-${second}` : ""}`
            );
        } else {
            value = value.replace(
                /^(\d{2})(\d{0,5})(\d{0,4}).*/,
                (_, ddd, first, second) =>
                    `(${ddd}) ${first}${second ? `-${second}` : ""}`
            );
        }

        event.target.value = value;
    });

    form.addEventListener("submit", (event) => {
        event.preventDefault();

        if (!validate()) {
            status.textContent =
                "Revise os campos destacados.";
            return;
        }

        status.textContent =
            "Dados preenchidos corretamente. O canal oficial de envio ainda precisa ser configurado.";
    });
})();
