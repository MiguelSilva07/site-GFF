# GFF Advocacia — Clone de Conceito

Esta versão foi construída a partir da arquitetura visual e da organização
observadas no site de referência fornecido pelo cliente.

A implementação é uma adaptação original para a identidade GFF:
- Guilherme Farias de França
- GFF
- #052637
- #082739
- #163B4E
- #FEDA9C
- Cormorant Garamond + Inter

## Mantido do projeto anterior
- Preloader circular de 2,5 segundos.
- Círculo de progresso.
- Logo GFF.
- Estátua da Justiça.
- Seção O Advogado com espaço para fotografia.
- Blog / Jurisprudência.
- HTML5 + CSS3 + JavaScript.
- Layout responsivo.

## Importante
O conteúdo profissional real do advogado, OAB, áreas de atuação,
telefone, endereço e demais dados devem ser preenchidos somente depois
que forem fornecidos pelo cliente.

A arquitetura do clone foi inspirada no site de referência, mas o conteúdo,
a identidade visual e os componentes foram desenvolvidos especificamente
para GFF.


## Contato e localização

A página inicial contém formulário de contato e mapa Google Maps incorporado para o Atlantic Tower.


## Layout aprovado — O Advogado

Seção organizada com fotografia à esquerda e apresentação profissional à direita, em composição Dark Minimal.
